// cosas requeridas por la actividad: 3 eventos
$(document).ready(function(){


$("#modos").click(function(){
    $("body").toggleClass("dark dark0");
});


});
